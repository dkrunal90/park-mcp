from pydantic import BaseModel, Field


class EchoRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


class EchoResponse(BaseModel):
    message: str
    normalized_message: str


class QueryRequest(BaseModel):
    sql: str = Field(min_length=1, max_length=10000)
    parameters: list[str | int | float | bool | None] = Field(default_factory=list)


class QueryResponse(BaseModel):
    columns: list[str]
    rows: list[list]
    row_count: int
