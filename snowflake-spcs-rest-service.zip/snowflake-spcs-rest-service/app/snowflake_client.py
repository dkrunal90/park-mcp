import os
from contextlib import contextmanager
from pathlib import Path

import snowflake.connector

from app.config import get_settings

TOKEN_PATH = Path("/snowflake/session/token")


def _connection_parameters() -> dict:
    settings = get_settings()
    params: dict = {
        "warehouse": settings.snowflake_warehouse,
        "database": settings.snowflake_database,
        "schema": settings.snowflake_schema,
        "role": settings.snowflake_role,
        "session_parameters": {"QUERY_TAG": "spcs-rest-service"},
    }
    params = {key: value for key, value in params.items() if value}

    # In SPCS, use the injected service token. Locally, use standard connector settings.
    if TOKEN_PATH.exists():
        params.update(
            host=os.getenv("SNOWFLAKE_HOST"),
            account=os.getenv("SNOWFLAKE_ACCOUNT"),
            authenticator="oauth",
            token=TOKEN_PATH.read_text(encoding="utf-8").strip(),
        )
    else:
        params.update(
            account=settings.snowflake_account,
            user=settings.snowflake_user,
            password=settings.snowflake_password,
        )
    return {key: value for key, value in params.items() if value is not None}


@contextmanager
def connection():
    conn = snowflake.connector.connect(**_connection_parameters())
    try:
        yield conn
    finally:
        conn.close()


def execute(sql: str, parameters: list) -> tuple[list[str], list[list]]:
    # This sample permits one statement per call. Production systems should expose
    # approved operations rather than arbitrary SQL from untrusted callers.
    if ";" in sql.rstrip().rstrip(";"):
        raise ValueError("Only one SQL statement is allowed")
    with connection() as conn, conn.cursor() as cursor:
        cursor.execute(sql, tuple(parameters))
        columns = [item[0] for item in cursor.description] if cursor.description else []
        rows = [list(row) for row in cursor.fetchall()] if cursor.description else []
        return columns, rows
