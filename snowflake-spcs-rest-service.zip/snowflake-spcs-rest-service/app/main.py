import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException

from app.config import get_settings
from app.logging_config import configure_logging
from app.models import EchoRequest, EchoResponse, QueryRequest, QueryResponse
from app.snowflake_client import execute

settings = get_settings()
configure_logging(settings.log_level)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info("service_start environment=%s", settings.environment)
    yield
    logger.info("service_stop")


app = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "service": settings.app_name, "version": settings.app_version}


@app.post("/v1/echo", response_model=EchoResponse)
def echo(request: EchoRequest) -> EchoResponse:
    normalized = " ".join(request.message.split())
    return EchoResponse(message=request.message, normalized_message=normalized)


@app.post("/v1/query", response_model=QueryResponse)
def query(request: QueryRequest) -> QueryResponse:
    try:
        columns, rows = execute(request.sql, request.parameters)
        return QueryResponse(columns=columns, rows=rows, row_count=len(rows))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("query_failed")
        raise HTTPException(status_code=500, detail="Snowflake query failed") from exc
