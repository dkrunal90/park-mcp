# Snowflake SPCS REST Service

A deployable VS Code project for a custom FastAPI REST service hosted on Snowpark Container Services (SPCS). It contains application code, tests, Docker packaging, Snowflake infrastructure SQL, a service specification template, VS Code configuration, and Make targets for the full lifecycle.

## What it creates

- Snowflake role, database, schema, warehouse, compute pool, image repository, and stage
- OCI image built for `linux/amd64` and pushed to Snowflake's image repository
- Long-running SPCS service with a public HTTPS endpoint
- `/health`, `/v1/echo`, and example `/v1/query` endpoints

> Security note: `/v1/query` is intentionally a development example. Do not expose arbitrary SQL to untrusted callers. Replace it with approved operations, stored procedures, or narrowly scoped tools before production use.

## Prerequisites

- Snowflake account with Snowpark Container Services available
- Docker or another OCI-compatible client
- Python 3.11+
- GNU Make and Bash
- Snowflake CLI (`snow`) with a working connection in `~/.snowflake/config.toml`
- A deployment identity able to run the bootstrap SQL. For production, separate the one-time administrator bootstrap from application deployment.

## Quick start

```bash
unzip snowflake-spcs-rest-service.zip
cd snowflake-spcs-rest-service
make init
# Edit .env. At minimum set SNOW_CONNECTION and SNOW_USER.
make install-dev
make test
make bootstrap
make image-push
make deploy
make status
make endpoints
```

Or run everything after editing `.env`:

```bash
make all
```

## Local development

```bash
make init
make install-dev
make local
curl http://localhost:8000/health
curl -X POST http://localhost:8000/v1/echo \
  -H 'content-type: application/json' \
  -d '{"message":"hello from VS Code"}'
```

To use `/v1/query` locally, populate the optional `SNOWFLAKE_*` values in `.env`.

## Main Make targets

```text
make init             Create .env
make install-dev      Install local dependencies
make test             Run unit tests
make local            Run FastAPI locally
make bootstrap        Create Snowflake infrastructure
make image-push       Build, authenticate, tag, and push image
make deploy           Render/upload spec and create or upgrade service
make status           Show service status
make endpoints        Show ingress endpoint
make logs             Read recent container logs
make suspend          Suspend service
make resume           Resume service
make destroy          Drop service and compute pool; retain data objects
```

## Authentication model

- **Deployment:** Snowflake CLI connection from your workstation or CI environment.
- **Docker registry:** `scripts/spcs.py` uses `snow spcs image-registry login` with the configured Snow CLI connection.
- **Workload to Snowflake:** `app/snowflake_client.py` detects `/snowflake/session/token` inside SPCS and uses it as an OAuth token. For local development, it uses standard connector environment variables.
- **Inbound REST endpoint:** Public SPCS endpoints are protected by Snowflake ingress authentication. If this service will be called by Azure AI Foundry or another external workload, add the caller authentication pattern required by your Snowflake account and validate identity/authorization before invoking business operations.

## Production hardening checklist

1. Replace arbitrary `/v1/query` with explicit tool endpoints.
2. Use immutable image tags or digests.
3. Split administrator bootstrap permissions from CI/CD deployment permissions.
4. Restrict Snowflake grants to required databases, schemas, functions, and Cortex objects.
5. Add request correlation IDs, structured logs, traces, metrics, and audit events.
6. Add input/output schemas, payload limits, timeouts, retries, and idempotency where needed.
7. Store external secrets using Snowflake secrets and external access integrations, not `.env` or the image.
8. Add a non-public/private connectivity design if public ingress is not acceptable.
9. Put API versioning and approved operation contracts in front of Cortex or MCP calls.
10. Add CI checks for lint, tests, image scanning, and deployment policy.

## Project structure

```text
app/                 FastAPI application and Snowflake client
infra/               Bootstrap, deploy, and destroy SQL
scripts/             Registry, image push, and spec rendering automation
spec/                SPCS service specification template
tests/               API unit tests
.vscode/              VS Code tasks, debugger, extensions
Dockerfile           Container image
Makefile             Local and deployment workflow
```

## Cleaning up

```bash
make destroy
```

The default destroy script drops the service and compute pool but deliberately keeps the database, warehouse, role, stage, and image repository. Destructive cleanup statements are commented out in `infra/99_destroy.sql`.
