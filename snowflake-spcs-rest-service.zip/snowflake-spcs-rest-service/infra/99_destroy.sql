USE ROLE ACCOUNTADMIN;
DROP SERVICE IF EXISTS &{SNOW_DATABASE}.&{SNOW_SCHEMA}.&{SNOW_SERVICE};
DROP COMPUTE POOL IF EXISTS &{SNOW_COMPUTE_POOL};
-- Deliberately retain the database, image repository, stage, warehouse, and role.
-- Uncomment only when you intend destructive cleanup:
-- DROP WAREHOUSE IF EXISTS &{SNOW_WAREHOUSE};
-- DROP DATABASE IF EXISTS &{SNOW_DATABASE};
-- DROP ROLE IF EXISTS &{SNOW_ROLE};
