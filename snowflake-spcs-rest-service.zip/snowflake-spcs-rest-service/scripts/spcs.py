#!/usr/bin/env python3
import argparse
import json
import os
import subprocess
from pathlib import Path
from string import Template


def required(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise SystemExit(f"Missing required environment variable: {name}")
    return value


def snow_json(query: str) -> list[dict]:
    connection = required("SNOW_CONNECTION")
    completed = subprocess.run(
        ["snow", "sql", "-c", connection, "-q", query, "--format", "json"],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


def repository_url() -> str:
    database = required("SNOW_DATABASE")
    schema = required("SNOW_SCHEMA")
    repository = required("SNOW_IMAGE_REPOSITORY")
    rows = snow_json(f"SHOW IMAGE REPOSITORIES LIKE '{repository}' IN SCHEMA {database}.{schema}")
    if not rows:
        raise SystemExit("Image repository not found. Run: make bootstrap")
    row = rows[0]
    for key in ("repository_url", "REPOSITORY_URL"):
        if key in row:
            return row[key]
    raise SystemExit(f"repository_url missing from Snowflake response: {row}")


def registry_login() -> None:
    connection = required("SNOW_CONNECTION")
    subprocess.run(
        ["snow", "spcs", "image-registry", "login", "-c", connection],
        check=True,
    )


def image_push() -> None:
    repo = repository_url()
    image_name = required("IMAGE_NAME")
    image_tag = required("IMAGE_TAG")
    local = f"{image_name}:{image_tag}"
    remote = f"{repo}/{image_name}:{image_tag}"
    subprocess.run(["docker", "tag", local, remote], check=True)
    subprocess.run(["docker", "push", remote], check=True)
    print(remote)


def render_spec(output: Path) -> None:
    values = dict(os.environ)
    values["REPOSITORY_URL"] = repository_url()
    values.setdefault("LOG_LEVEL", "INFO")
    template = Template(Path("spec/service.yaml.template").read_text(encoding="utf-8"))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(template.substitute(values), encoding="utf-8")
    print(output)


def validate_spec(path: Path) -> None:
    try:
        import yaml
    except ImportError as exc:
        raise SystemExit("PyYAML is required. Run: make install-dev") from exc
    document = yaml.safe_load(path.read_text(encoding="utf-8"))
    spec = document.get("spec", {})
    if not spec.get("containers") or not spec.get("endpoints"):
        raise SystemExit("Specification must include containers and endpoints")
    print("service specification is valid YAML")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("registry-login")
    sub.add_parser("image-push")
    render = sub.add_parser("render-spec")
    render.add_argument("--output", type=Path, required=True)
    validate = sub.add_parser("validate-spec")
    validate.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "registry-login": registry_login()
    elif args.command == "image-push": image_push()
    elif args.command == "render-spec": render_spec(args.output)
    elif args.command == "validate-spec": validate_spec(args.input)


if __name__ == "__main__":
    main()
