from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_echo_normalizes_whitespace():
    response = client.post("/v1/echo", json={"message": " hello   Snowflake "})
    assert response.status_code == 200
    assert response.json()["normalized_message"] == "hello Snowflake"


def test_echo_rejects_empty_message():
    response = client.post("/v1/echo", json={"message": ""})
    assert response.status_code == 422
